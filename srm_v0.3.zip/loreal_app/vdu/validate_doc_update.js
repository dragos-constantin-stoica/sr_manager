function(newdoc, olddoc, userctx, secobj) {
	if(newdoc.doctype == "event"){
		newdoc.audit = {};
		newdoc.audit.author = userctx.name;
		var ts = new Date();
		newdoc.audit.timestamp = ts.toISOString();
	}
        
}