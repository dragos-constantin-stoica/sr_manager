dhtmlxGantt v.2.0 build 130823

This software is allowed to use under GPL or you need to obtain Commercial or Enterise License 
 to use it in non-GPL project. Please contact sales@dhtmlx.com for details

(c) Dinamenta, UAB.



Useful links
-------------

- Online  documentation
	http://docs.dhtmlx.com/gantt/

- Downloadable documentation
	CHM version
		http://dhtmlx.com/regular/dhtmlxGantt_docs_chm.zip
	HTML version
		http://dhtmlx.com/regular/dhtmlxGantt_docs_html.zip
	
- Support forum
	http://forum.dhtmlx.com/viewforum.php?f=15