	webix.i18n.locales["be-BY"]={
	groupDelimiter:" ",
	groupSize:3,
	decimalDelimiter:",",
	decimalSize:2,

	dateFormat:"%d.%m.%Y",
	timeFormat:"%H:%i",
	longDateFormat:"%d %F %Y",
	fullDateFormat:"%d.%m.%Y %H:%i",

	price:"{obj} руб.",
	priceSettings:{
		groupSize:3,
		groupDelimiter:" ",
		decimalDelimiter:"",
		decimalSize:0
	},

	calendar:{
		monthFull:["Студзень", "Люты", "Сакавік", "Красавік", "Травень", "Чэрвень", "Ліпень", "Жнівень", "Верасень", "Кастрычнік", "Лістапад", "Снежань"],
		monthShort:["Студз", "Лют", "Сак", "Крас", "Трав", "Чэр", "Ліп", "Жнів", "Вер", "Каст", "Ліст", "Снеж"],
		dayFull:[ "Нядзеля", "Панядзелак", "Аўторак", "Серада", "Чацвер", "Пятніца", "Субота"],
    	dayShort:["Нд", "Пн", "Аўт", "Ср", "Чцв", "Пт", "Сб"],
		hours: "Гадзіны",
		minutes: "Хвіліны",
		done: "Гатова"
	},

	controls:{
    	select:"Выбраць"
    }
};