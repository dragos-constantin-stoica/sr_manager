//outlets
var outletstable = {
	
	outletsdata: [],
	
	setOutletsData: function(outletsdata){
		this.outletsdata = outletsdata;
	},
	
	getOutletsData: function(){
		return this.outletsdata;
	}
};

//TODO - keep history of SR for a given outlet